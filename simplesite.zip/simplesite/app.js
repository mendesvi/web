
var padrao = /[^a-zà-ú]/gi; //regex para nome


function checa_numero(nome)
{
    return /\d/.test(nome);
}

function validar()
{
  let nome = document.getElementById("nome").value;
  var valida_nome = nome.match(padrao); //ver se precisa
    if(checa_numero(nome) || nome == "")//teste pra verificar entrada
    { 
       alert("Nome não pode ter números ou digitos especiais")
    }
    else
    {
       alert("Nome correto!")
    }
      
   
 }

 /*function valida_tele(tel) 
 {
  var rtel = /(\(?\d{2}\)?\s)?(\d{4,5}\-\d{4})/g; //regex pra telefone
  let tel = document.getElementById("tel").value;
  if(rtel.test(tel))
  {
    alert("valido")

  }
  else
  {
    alert("invalido");
  }
}*/
    